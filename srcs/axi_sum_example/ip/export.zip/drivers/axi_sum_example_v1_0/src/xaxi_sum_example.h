// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XAXI_SUM_EXAMPLE_H
#define XAXI_SUM_EXAMPLE_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xaxi_sum_example_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
    u16 DeviceId;
    u64 Control_BaseAddress;
} XAxi_sum_example_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XAxi_sum_example;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XAxi_sum_example_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XAxi_sum_example_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XAxi_sum_example_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XAxi_sum_example_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XAxi_sum_example_Initialize(XAxi_sum_example *InstancePtr, u16 DeviceId);
XAxi_sum_example_Config* XAxi_sum_example_LookupConfig(u16 DeviceId);
int XAxi_sum_example_CfgInitialize(XAxi_sum_example *InstancePtr, XAxi_sum_example_Config *ConfigPtr);
#else
int XAxi_sum_example_Initialize(XAxi_sum_example *InstancePtr, const char* InstanceName);
int XAxi_sum_example_Release(XAxi_sum_example *InstancePtr);
#endif

void XAxi_sum_example_Start(XAxi_sum_example *InstancePtr);
u32 XAxi_sum_example_IsDone(XAxi_sum_example *InstancePtr);
u32 XAxi_sum_example_IsIdle(XAxi_sum_example *InstancePtr);
u32 XAxi_sum_example_IsReady(XAxi_sum_example *InstancePtr);
void XAxi_sum_example_EnableAutoRestart(XAxi_sum_example *InstancePtr);
void XAxi_sum_example_DisableAutoRestart(XAxi_sum_example *InstancePtr);

void XAxi_sum_example_Set_in_r(XAxi_sum_example *InstancePtr, u64 Data);
u64 XAxi_sum_example_Get_in_r(XAxi_sum_example *InstancePtr);
void XAxi_sum_example_Set_out_r(XAxi_sum_example *InstancePtr, u64 Data);
u64 XAxi_sum_example_Get_out_r(XAxi_sum_example *InstancePtr);
void XAxi_sum_example_Set_n_elements(XAxi_sum_example *InstancePtr, u32 Data);
u32 XAxi_sum_example_Get_n_elements(XAxi_sum_example *InstancePtr);
void XAxi_sum_example_Set_n_rounds(XAxi_sum_example *InstancePtr, u32 Data);
u32 XAxi_sum_example_Get_n_rounds(XAxi_sum_example *InstancePtr);

void XAxi_sum_example_InterruptGlobalEnable(XAxi_sum_example *InstancePtr);
void XAxi_sum_example_InterruptGlobalDisable(XAxi_sum_example *InstancePtr);
void XAxi_sum_example_InterruptEnable(XAxi_sum_example *InstancePtr, u32 Mask);
void XAxi_sum_example_InterruptDisable(XAxi_sum_example *InstancePtr, u32 Mask);
void XAxi_sum_example_InterruptClear(XAxi_sum_example *InstancePtr, u32 Mask);
u32 XAxi_sum_example_InterruptGetEnabled(XAxi_sum_example *InstancePtr);
u32 XAxi_sum_example_InterruptGetStatus(XAxi_sum_example *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
