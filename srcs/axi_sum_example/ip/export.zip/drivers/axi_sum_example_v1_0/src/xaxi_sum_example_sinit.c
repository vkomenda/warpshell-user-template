// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xaxi_sum_example.h"

extern XAxi_sum_example_Config XAxi_sum_example_ConfigTable[];

XAxi_sum_example_Config *XAxi_sum_example_LookupConfig(u16 DeviceId) {
	XAxi_sum_example_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XAXI_SUM_EXAMPLE_NUM_INSTANCES; Index++) {
		if (XAxi_sum_example_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XAxi_sum_example_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XAxi_sum_example_Initialize(XAxi_sum_example *InstancePtr, u16 DeviceId) {
	XAxi_sum_example_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XAxi_sum_example_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XAxi_sum_example_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

