// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xaxi_sum_example.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XAxi_sum_example_CfgInitialize(XAxi_sum_example *InstancePtr, XAxi_sum_example_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XAxi_sum_example_Start(XAxi_sum_example *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAxi_sum_example_ReadReg(InstancePtr->Control_BaseAddress, XAXI_SUM_EXAMPLE_CONTROL_ADDR_AP_CTRL) & 0x80;
    XAxi_sum_example_WriteReg(InstancePtr->Control_BaseAddress, XAXI_SUM_EXAMPLE_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XAxi_sum_example_IsDone(XAxi_sum_example *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAxi_sum_example_ReadReg(InstancePtr->Control_BaseAddress, XAXI_SUM_EXAMPLE_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XAxi_sum_example_IsIdle(XAxi_sum_example *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAxi_sum_example_ReadReg(InstancePtr->Control_BaseAddress, XAXI_SUM_EXAMPLE_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XAxi_sum_example_IsReady(XAxi_sum_example *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAxi_sum_example_ReadReg(InstancePtr->Control_BaseAddress, XAXI_SUM_EXAMPLE_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XAxi_sum_example_EnableAutoRestart(XAxi_sum_example *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAxi_sum_example_WriteReg(InstancePtr->Control_BaseAddress, XAXI_SUM_EXAMPLE_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XAxi_sum_example_DisableAutoRestart(XAxi_sum_example *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAxi_sum_example_WriteReg(InstancePtr->Control_BaseAddress, XAXI_SUM_EXAMPLE_CONTROL_ADDR_AP_CTRL, 0);
}

void XAxi_sum_example_Set_in_r(XAxi_sum_example *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAxi_sum_example_WriteReg(InstancePtr->Control_BaseAddress, XAXI_SUM_EXAMPLE_CONTROL_ADDR_IN_R_DATA, (u32)(Data));
    XAxi_sum_example_WriteReg(InstancePtr->Control_BaseAddress, XAXI_SUM_EXAMPLE_CONTROL_ADDR_IN_R_DATA + 4, (u32)(Data >> 32));
}

u64 XAxi_sum_example_Get_in_r(XAxi_sum_example *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAxi_sum_example_ReadReg(InstancePtr->Control_BaseAddress, XAXI_SUM_EXAMPLE_CONTROL_ADDR_IN_R_DATA);
    Data += (u64)XAxi_sum_example_ReadReg(InstancePtr->Control_BaseAddress, XAXI_SUM_EXAMPLE_CONTROL_ADDR_IN_R_DATA + 4) << 32;
    return Data;
}

void XAxi_sum_example_Set_out_r(XAxi_sum_example *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAxi_sum_example_WriteReg(InstancePtr->Control_BaseAddress, XAXI_SUM_EXAMPLE_CONTROL_ADDR_OUT_R_DATA, (u32)(Data));
    XAxi_sum_example_WriteReg(InstancePtr->Control_BaseAddress, XAXI_SUM_EXAMPLE_CONTROL_ADDR_OUT_R_DATA + 4, (u32)(Data >> 32));
}

u64 XAxi_sum_example_Get_out_r(XAxi_sum_example *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAxi_sum_example_ReadReg(InstancePtr->Control_BaseAddress, XAXI_SUM_EXAMPLE_CONTROL_ADDR_OUT_R_DATA);
    Data += (u64)XAxi_sum_example_ReadReg(InstancePtr->Control_BaseAddress, XAXI_SUM_EXAMPLE_CONTROL_ADDR_OUT_R_DATA + 4) << 32;
    return Data;
}

void XAxi_sum_example_Set_n_elements(XAxi_sum_example *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAxi_sum_example_WriteReg(InstancePtr->Control_BaseAddress, XAXI_SUM_EXAMPLE_CONTROL_ADDR_N_ELEMENTS_DATA, Data);
}

u32 XAxi_sum_example_Get_n_elements(XAxi_sum_example *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAxi_sum_example_ReadReg(InstancePtr->Control_BaseAddress, XAXI_SUM_EXAMPLE_CONTROL_ADDR_N_ELEMENTS_DATA);
    return Data;
}

void XAxi_sum_example_Set_n_rounds(XAxi_sum_example *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAxi_sum_example_WriteReg(InstancePtr->Control_BaseAddress, XAXI_SUM_EXAMPLE_CONTROL_ADDR_N_ROUNDS_DATA, Data);
}

u32 XAxi_sum_example_Get_n_rounds(XAxi_sum_example *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAxi_sum_example_ReadReg(InstancePtr->Control_BaseAddress, XAXI_SUM_EXAMPLE_CONTROL_ADDR_N_ROUNDS_DATA);
    return Data;
}

void XAxi_sum_example_InterruptGlobalEnable(XAxi_sum_example *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAxi_sum_example_WriteReg(InstancePtr->Control_BaseAddress, XAXI_SUM_EXAMPLE_CONTROL_ADDR_GIE, 1);
}

void XAxi_sum_example_InterruptGlobalDisable(XAxi_sum_example *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAxi_sum_example_WriteReg(InstancePtr->Control_BaseAddress, XAXI_SUM_EXAMPLE_CONTROL_ADDR_GIE, 0);
}

void XAxi_sum_example_InterruptEnable(XAxi_sum_example *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XAxi_sum_example_ReadReg(InstancePtr->Control_BaseAddress, XAXI_SUM_EXAMPLE_CONTROL_ADDR_IER);
    XAxi_sum_example_WriteReg(InstancePtr->Control_BaseAddress, XAXI_SUM_EXAMPLE_CONTROL_ADDR_IER, Register | Mask);
}

void XAxi_sum_example_InterruptDisable(XAxi_sum_example *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XAxi_sum_example_ReadReg(InstancePtr->Control_BaseAddress, XAXI_SUM_EXAMPLE_CONTROL_ADDR_IER);
    XAxi_sum_example_WriteReg(InstancePtr->Control_BaseAddress, XAXI_SUM_EXAMPLE_CONTROL_ADDR_IER, Register & (~Mask));
}

void XAxi_sum_example_InterruptClear(XAxi_sum_example *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAxi_sum_example_WriteReg(InstancePtr->Control_BaseAddress, XAXI_SUM_EXAMPLE_CONTROL_ADDR_ISR, Mask);
}

u32 XAxi_sum_example_InterruptGetEnabled(XAxi_sum_example *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XAxi_sum_example_ReadReg(InstancePtr->Control_BaseAddress, XAXI_SUM_EXAMPLE_CONTROL_ADDR_IER);
}

u32 XAxi_sum_example_InterruptGetStatus(XAxi_sum_example *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XAxi_sum_example_ReadReg(InstancePtr->Control_BaseAddress, XAXI_SUM_EXAMPLE_CONTROL_ADDR_ISR);
}

